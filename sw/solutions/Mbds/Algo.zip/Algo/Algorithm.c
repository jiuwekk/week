/*
 * File: Algorithm.c
 *
 * Code generated for Simulink model 'Algorithm'.
 *
 * Model version                  : 1.1041
 * Simulink Coder version         : 8.13 (R2017b) 24-Jul-2017
 * C/C++ source code generated on : Thu Sep 30 13:59:21 2021
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. RAM efficiency
 * Validation result: Not run
 */

#include "Algorithm.h"
#include "Algorithm_private.h"
#define Algorithm_IN_Initial_state     (1U)
#define Algorithm_IN_LowVolt3          (1U)
#define Algorithm_IN_NO_ACTIVE_CHILD   (0U)
#define Algorithm_IN_Normal            (1U)
#define Algorithm_IN_Normal_k          (2U)
#define Algorithm_IN_OC1               (2U)
#define Algorithm_IN_OC2               (3U)
#define Algorithm_IN_OverVolt3         (2U)
#define Algorithm_IN_Start_int         (2U)
#define Algorithm_IN_wait_perchg       (3U)

const AlgoFun_inspect_bus Algorithm_rtZAlgoFun_inspect_bus = {
  0.0F,                                /* KCurrPIComp */
  0.0F,                                /* ThetaRawE */
  0.0F,                                /* ThetaRawM */
  0.0F,                                /* Angle_park */
  0.0F,                                /* Angle_Ipark */
  0.0F,                                /* Nm_pu */
  0.0F,                                /* Ne_pu */
  0.0F,                                /* Clarke_Alpha */
  0.0F,                                /* Clarke_Beta */
  0.0F,                                /* IdRef */
  0.0F,                                /* IqRef */
  0.0F,                                /* PI_Id_Ui */
  0.0F,                                /* PI_Iq_Ui */
  0.0F,                                /* Ipark_Alpha */
  0.0F,                                /* Ipark_Beta */
  0.0F,                                /* VsRef1 */
  0.0F,                                /* Ld */
  0.0F,                                /* IdWeak */
  0.0F,                                /* PI_IdWeak_Ui */
  0.0F,                                /* AngleMTPA */
  0.0F,                                /* VsRef2 */
  0.0F,                                /* AngleWeak */
  0.0F,                                /* PI_Angle_Ui */
  0.0F,                                /* IsRef */
  0.0F,                                /* If */
  0.0F,                                /* TabNStart */
  0.0F,                                /* TabNEnd */
  0.0F,                                /* TabNStep */
  0.0F,                                /* TqMax */
  0.0F,                                /* TqLimit */
  0.0F,                                /* TqReal */
  0.0F,                                /* IdFbkFil */
  0.0F,                                /* IqFbkFil */
  0.0F,                                /* UdFil */
  0.0F,                                /* UqFil */
  0.0F,                                /* UsFil */
  0.0F,                                /* IsFbkFil */
  0.0F                                 /* IsFbk */
} ;                                    /* AlgoFun_inspect_bus ground */

/* Exported block states */
AlgoFun_inspect_bus AlgoFun;           /* Simulink.Signal object 'AlgoFun' */

/* Block signals and states (auto storage) */
DW_Algorithm_T Algorithm_DW;

/* Real-time model */
RT_MODEL_Algorithm_T Algorithm_M_;
RT_MODEL_Algorithm_T *const Algorithm_M = &Algorithm_M_;
uint32_T plook_u32ff_evenca(real32_T u, real32_T bp0, real32_T bpSpace, uint32_T
  maxIndex, real32_T *fraction)
{
  uint32_T bpIndex;
  real32_T invSpc;
  real32_T fbpIndex;

  /* Prelookup - Index and Fraction
     Index Search method: 'even'
     Extrapolation method: 'Clip'
     Use previous index: 'off'
     Use last breakpoint for index at or above upper limit: 'on'
     Remove protection against out-of-range input in generated code: 'off'
   */
  if (u <= bp0) {
    bpIndex = 0UL;
    *fraction = 0.0F;
  } else {
    invSpc = 1.0F / bpSpace;
    fbpIndex = (u - bp0) * invSpc;
    if (fbpIndex < (real32_T)maxIndex) {
      bpIndex = (uint32_T)fbpIndex;
      *fraction = (u - ((real32_T)bpIndex * bpSpace + bp0)) * invSpc;
    } else {
      bpIndex = maxIndex;
      *fraction = 0.0F;
    }
  }

  return bpIndex;
}

real32_T intrp2d_fu32fla_pw(const uint32_T bpIndex[], const real32_T frac[],
  const real32_T table[], uint32_T stride, const uint32_T maxIndex[])
{
  real32_T y;
  real32_T yR_1d;
  uint32_T offset_1d;

  /* Interpolation 2-D
     Interpolation method: 'Linear'
     Use last breakpoint for index at or above upper limit: 'on'
     Overflow mode: 'portable wrapping'
   */
  offset_1d = (uint32_T)((uint32_T)(bpIndex[1UL] * stride) + bpIndex[0UL]);
  if (bpIndex[0UL] == maxIndex[0UL]) {
    y = table[offset_1d];
  } else {
    y = (table[(uint32_T)(offset_1d + 1UL)] - table[offset_1d]) * frac[0UL] +
      table[offset_1d];
  }

  if (bpIndex[1UL] == maxIndex[1UL]) {
  } else {
    offset_1d += stride;
    if (bpIndex[0UL] == maxIndex[0UL]) {
      yR_1d = table[offset_1d];
    } else {
      yR_1d = (table[(uint32_T)(offset_1d + 1UL)] - table[offset_1d]) * frac[0UL]
        + table[offset_1d];
    }

    y += (yR_1d - y) * frac[1UL];
  }

  return y;
}

real32_T intrp1d_fu32fla_pw(uint32_T bpIndex, real32_T frac, const real32_T
  table[], uint32_T maxIndex)
{
  real32_T y;

  /* Interpolation 1-D
     Interpolation method: 'Linear'
     Use last breakpoint for index at or above upper limit: 'on'
     Overflow mode: 'portable wrapping'
   */
  if (bpIndex == maxIndex) {
    y = table[bpIndex];
  } else {
    y = (table[(uint32_T)(bpIndex + 1UL)] - table[bpIndex]) * frac +
      table[bpIndex];
  }

  return y;
}

real32_T rt_atan2f_snf(real32_T u0, real32_T u1)
{
  real32_T y;
  int16_T u0_0;
  int16_T u1_0;
  if (rtIsNaNF(u0) || rtIsNaNF(u1)) {
    y = (rtNaNF);
  } else if (rtIsInfF(u0) && rtIsInfF(u1)) {
    if (u0 > 0.0F) {
      u0_0 = 1;
    } else {
      u0_0 = -1;
    }

    if (u1 > 0.0F) {
      u1_0 = 1;
    } else {
      u1_0 = -1;
    }

    y = atan2f((real32_T)u0_0, (real32_T)u1_0);
  } else if (u1 == 0.0F) {
    if (u0 > 0.0F) {
      y = RT_PIF / 2.0F;
    } else if (u0 < 0.0F) {
      y = -(RT_PIF / 2.0F);
    } else {
      y = 0.0F;
    }
  } else {
    y = atan2f(u0, u1);
  }

  return y;
}

real32_T rt_hypotf_snf(real32_T u0, real32_T u1)
{
  real32_T y;
  real32_T a;
  a = fabsf(u0);
  y = fabsf(u1);
  if (a < y) {
    a /= y;
    y *= sqrtf(a * a + 1.0F);
  } else if (a > y) {
    y /= a;
    y = sqrtf(y * y + 1.0F) * a;
  } else {
    if (!rtIsNaNF(y)) {
      y = a * 1.41421354F;
    }
  }

  return y;
}

/* Model step function */
void AgoCall(void)
{
  uint32_T bpIdx;
  uint32_T bpIndices[2];
  uint32_T bpIndices_0[2];
  real32_T fractions[2];
  boolean_T rtb_Switch_a;
  real32_T rtb_Gain3[3];
  real32_T rtb_KCurrPIComp;
  real32_T rtb_Volt;
  uint32_T rtb_BitwiseOperator;
  boolean_T rtb_Switch1_f;
  real32_T rtb_Nm_pu;
  real32_T rtb_PwmFreq;
  real32_T rtb_Divide;
  real32_T rtb_Gain1_n;
  real32_T rtb_Divide_o;
  real32_T rtb_ParkCompTheta;
  real32_T rtb_Ago_Out_Cur_loop_Id;
  real32_T rtb_Ago_Out_Cur_loop_Iq;
  real32_T rtb_Ago_Out_Cur_loop_Ud;
  real32_T rtb_Ago_Out_Cur_loop_Uq;
  real32_T rtb_Ago_Out_Cur_loop_Vs;
  real32_T rtb_Iq_Table1;
  real32_T rtb_Switch_or;
  real32_T rtb_xtheta;
  real32_T rtb_xr;
  real32_T rtb_Add_n;
  real32_T rtb_Add_cj;
  real32_T rtb_Saturation1;
  real32_T rtb_Add_a;
  real32_T rtb_SumofElements;
  real32_T rtb_Id_Table1;
  real32_T rtb_Gain_a[2];
  uint16_T rtb_Add_g;
  int16_T IntIal_enable;
  real32_T rtb_cur_uvw_pu_idx_0;
  real32_T rtb_cur_uvw_pu_idx_1;
  real32_T rtb_cur_uvw_pu_idx_2;
  real32_T Fcn_tmp;
  real32_T rtb_Nm_pu_tmp;

  /* Asynchronous task reads absolute time. Data (absolute time)
     transfers from high priority task (base rate) to low priority
     task (asynchronous rate). Double buffers are used to ensure
     data integrity.
     -- rtmH2LBufBeingRead is the index of the buffer being read
     -- rtmH2LLastBufWr is the index of the buffer that is written last.
   */
  if (Algorithm_M->Timing.rtmH2LLastBufWr1 == 0) {
    Algorithm_M->Timing.rtmH2LBufBeingRead1 = 0;
    Algorithm_M->Timing.clockTick1 = Algorithm_M->Timing.rtmH2LDbBufClockTick1[0];
  } else {
    Algorithm_M->Timing.rtmH2LBufBeingRead1 = 1;
    Algorithm_M->Timing.clockTick1 = Algorithm_M->Timing.rtmH2LDbBufClockTick1[1];
  }

  /* RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_AgoCall_at_outport_1' incorporates:
   *  SubSystem: '<Root>/Function-Call Subsystem'
   */
  /* Gain: '<S76>/Gain' incorporates:
   *  DataStoreRead: '<S1>/Data Store Read1'
   */
  rtb_KCurrPIComp = 1.0F / PMSM_Param.CurNorm;
  rtb_cur_uvw_pu_idx_0 = rtb_KCurrPIComp * PMSM_Input.AgoSample.CurU;

  /* Switch: '<S76>/Switch' incorporates:
   *  Constant: '<S76>/SwapPhase'
   *  DataStoreRead: '<S1>/Data Store Read1'
   */
  if (PMSM_Param.VWDirChg != 0U) {
    rtb_Switch_or = PMSM_Input.AgoSample.CurW;
  } else {
    rtb_Switch_or = PMSM_Input.AgoSample.CurV;
  }

  /* Gain: '<S76>/Gain' */
  rtb_cur_uvw_pu_idx_1 = rtb_KCurrPIComp * rtb_Switch_or;

  /* Switch: '<S76>/Switch' incorporates:
   *  Constant: '<S76>/SwapPhase'
   *  DataStoreRead: '<S1>/Data Store Read1'
   */
  if (PMSM_Param.VWDirChg != 0U) {
    rtb_Switch_or = PMSM_Input.AgoSample.CurV;
  } else {
    rtb_Switch_or = PMSM_Input.AgoSample.CurW;
  }

  /* Gain: '<S76>/Gain' */
  rtb_cur_uvw_pu_idx_2 = rtb_KCurrPIComp * rtb_Switch_or;

  /* MinMax: '<S10>/MinMax' incorporates:
   *  Abs: '<S10>/Abs'
   */
  rtb_KCurrPIComp = fmaxf(fmaxf(fabsf(rtb_cur_uvw_pu_idx_0), fabsf
    (rtb_cur_uvw_pu_idx_1)), fabsf(rtb_cur_uvw_pu_idx_2));

  /* Chart: '<S10>/OverCur12' incorporates:
   *  MinMax: '<S10>/MinMax'
   */
  rtb_Switch_a = (rtb_KCurrPIComp > PMSM_Param.OC1);
  if (!(rtb_Switch_a && Algorithm_DW.condWasTrueLastTime_1)) {
    Algorithm_DW.durationOperatorLastReferenceTi =
      ((Algorithm_M->Timing.clockTick1) * 0.0001);
  }

  Algorithm_DW.condWasTrueLastTime_1 = rtb_Switch_a;
  rtb_Switch_a = (rtb_KCurrPIComp > PMSM_Param.OC2);
  if (!(rtb_Switch_a && Algorithm_DW.condWasTrueLastTime_1_d)) {
    Algorithm_DW.durationOperatorLastReference_f =
      ((Algorithm_M->Timing.clockTick1) * 0.0001);
  }

  Algorithm_DW.condWasTrueLastTime_1_d = rtb_Switch_a;

  /* Gateway: Function-Call
     Subsystem/Fault/jugment/OverCur12 */
  /* During: Function-Call
     Subsystem/Fault/jugment/OverCur12 */
  if (Algorithm_DW.is_active_c7_Algorithm == 0U) {
    /* Entry: Function-Call
       Subsystem/Fault/jugment/OverCur12 */
    Algorithm_DW.is_active_c7_Algorithm = 1U;

    /* Entry Internal: Function-Call
       Subsystem/Fault/jugment/OverCur12 */
    /* Transition: '<S19>:9' */
    Algorithm_DW.durationOperatorLastReference_f =
      ((Algorithm_M->Timing.clockTick1) * 0.0001);
    Algorithm_DW.condWasTrueLastTime_1_d = (rtb_KCurrPIComp > PMSM_Param.OC2);

    /* Entry Internal 'jugment': '<S19>:8' */
    /* Transition: '<S19>:3' */
    Algorithm_DW.durationOperatorLastReferenceTi =
      ((Algorithm_M->Timing.clockTick1) * 0.0001);
    Algorithm_DW.is_jugment = Algorithm_IN_Normal;
    Algorithm_DW.condWasTrueLastTime_1 = (rtb_KCurrPIComp > PMSM_Param.OC1);
  } else {
    /* During 'jugment': '<S19>:8' */
    /* '<S19>:11:1' sf_internal_predicateOutput = ... */
    /* '<S19>:11:1' duration(Max_Cur_uvw_pu>PMSM_Param.OC2,usec)>300; */
    rtb_Switch_a = (rtb_KCurrPIComp > PMSM_Param.OC2);
    if (!(rtb_Switch_a && Algorithm_DW.condWasTrueLastTime_1_d)) {
      Algorithm_DW.durationOperatorLastReference_f =
        ((Algorithm_M->Timing.clockTick1) * 0.0001);
    }

    Algorithm_DW.condWasTrueLastTime_1_d = rtb_Switch_a;
    if ((((Algorithm_M->Timing.clockTick1) * 0.0001) -
         Algorithm_DW.durationOperatorLastReference_f) * 1.0E+6 > 300.0) {
      /* Transition: '<S19>:11' */
      /* Exit Internal 'jugment': '<S19>:8' */
      if (Algorithm_DW.is_jugment == 2U) {
        /* Exit 'OC1': '<S19>:5' */
        /* '<S19>:5:1' OC_fault(1)=0; */
        Algorithm_DW.OC_fault[0] = 0U;
        Algorithm_DW.is_jugment = Algorithm_IN_NO_ACTIVE_CHILD;
      } else {
        Algorithm_DW.is_jugment = Algorithm_IN_NO_ACTIVE_CHILD;
      }

      Algorithm_DW.is_jugment = Algorithm_IN_OC2;

      /* Entry 'OC2': '<S19>:6' */
      /* '<S19>:6:1' OC_fault(2)=1; */
      Algorithm_DW.OC_fault[1] = 1U;
    } else {
      switch (Algorithm_DW.is_jugment) {
       case Algorithm_IN_Normal:
        /* During 'Normal': '<S19>:2' */
        /* '<S19>:12:1' sf_internal_predicateOutput = ... */
        /* '<S19>:12:1' duration( Max_Cur_uvw_pu>PMSM_Param.OC1,usec)>300; */
        rtb_Switch_a = (rtb_KCurrPIComp > PMSM_Param.OC1);
        if (!(rtb_Switch_a && Algorithm_DW.condWasTrueLastTime_1)) {
          Algorithm_DW.durationOperatorLastReferenceTi =
            ((Algorithm_M->Timing.clockTick1) * 0.0001);
        }

        Algorithm_DW.condWasTrueLastTime_1 = rtb_Switch_a;
        if ((((Algorithm_M->Timing.clockTick1) * 0.0001) -
             Algorithm_DW.durationOperatorLastReferenceTi) * 1.0E+6 > 300.0) {
          /* Transition: '<S19>:12' */
          Algorithm_DW.is_jugment = Algorithm_IN_OC1;

          /* Entry 'OC1': '<S19>:5' */
          /* '<S19>:5:1' OC_fault(1)=1; */
          Algorithm_DW.OC_fault[0] = 1U;
        }
        break;

       case Algorithm_IN_OC1:
        /* During 'OC1': '<S19>:5' */
        /* '<S19>:13:1' sf_internal_predicateOutput = ... */
        /* '<S19>:13:1' Max_Cur_uvw_pu<PMSM_Param.OC1/2; */
        if (rtb_KCurrPIComp < PMSM_Param.OC1 / 2.0F) {
          /* Transition: '<S19>:13' */
          /* Exit 'OC1': '<S19>:5' */
          /* '<S19>:5:1' OC_fault(1)=0; */
          Algorithm_DW.OC_fault[0] = 0U;
          Algorithm_DW.durationOperatorLastReferenceTi =
            ((Algorithm_M->Timing.clockTick1) * 0.0001);
          Algorithm_DW.is_jugment = Algorithm_IN_Normal;
          Algorithm_DW.condWasTrueLastTime_1 = (rtb_KCurrPIComp > PMSM_Param.OC1);
        }
        break;

       default:
        /* During 'OC2': '<S19>:6' */
        break;
      }
    }
  }

  /* End of Chart: '<S10>/OverCur12' */

  /* Product: '<S76>/Divide' incorporates:
   *  Constant: '<S76>/Constant2'
   *  DataStoreRead: '<S1>/Data Store Read1'
   */
  rtb_KCurrPIComp = 1.0F / PMSM_Input.AppSample.VoltCap * PMSM_Param.VoltNorm;

  /* Saturate: '<S76>/Saturation' */
  if (rtb_KCurrPIComp > 5.0F) {
    rtb_KCurrPIComp = 5.0F;
  } else {
    if (rtb_KCurrPIComp < 0.0001F) {
      rtb_KCurrPIComp = 0.0001F;
    }
  }

  /* End of Saturate: '<S76>/Saturation' */

  /* Gain: '<S10>/Gain2' incorporates:
   *  Math: '<S10>/Math Function'
   *
   * About '<S10>/Math Function':
   *  Operator: reciprocal
   */
  rtb_Volt = 1.0F / rtb_KCurrPIComp * PMSM_Param.VoltNorm;

  /* Chart: '<S10>/OverLowVolt3' incorporates:
   *  DataStoreRead: '<S1>/Data Store Read1'
   */
  /* Gateway: Function-Call
     Subsystem/Fault/jugment/OverLowVolt3 */
  /* During: Function-Call
     Subsystem/Fault/jugment/OverLowVolt3 */
  if (Algorithm_DW.is_active_c8_Algorithm == 0U) {
    /* Entry: Function-Call
       Subsystem/Fault/jugment/OverLowVolt3 */
    Algorithm_DW.is_active_c8_Algorithm = 1U;

    /* Entry Internal: Function-Call
       Subsystem/Fault/jugment/OverLowVolt3 */
    /* Entry Internal 'OV': '<S20>:3' */
    /* Transition: '<S20>:6' */
    Algorithm_DW.is_OV = Algorithm_IN_Normal;

    /* Entry Internal 'LV': '<S20>:22' */
    /* Transition: '<S20>:27' */
    Algorithm_DW.is_LV = Algorithm_IN_wait_perchg;

    /* Entry 'wait_perchg': '<S20>:24' */
    /* '<S20>:24:1' OV_fault(2)=0; */
    Algorithm_DW.OV_fault[1] = 0U;
  } else {
    /* During 'OV': '<S20>:3' */
    if ((Algorithm_DW.is_OV == 1U) && (rtb_Volt > PMSM_Param.OV3)) {
      /* During 'Normal': '<S20>:5' */
      /* '<S20>:12:1' sf_internal_predicateOutput = ... */
      /* '<S20>:12:1' Volt>PMSM_Param.OV3; */
      /* Transition: '<S20>:12' */
      Algorithm_DW.is_OV = Algorithm_IN_OverVolt3;

      /* Entry 'OverVolt3': '<S20>:11' */
      /* '<S20>:11:1' OV_fault(1)=1; */
      Algorithm_DW.OV_fault[0] = 1U;
    } else {
      /* During 'OverVolt3': '<S20>:11' */
    }

    /* During 'LV': '<S20>:22' */
    switch (Algorithm_DW.is_LV) {
     case Algorithm_IN_LowVolt3:
      /* During 'LowVolt3': '<S20>:25' */
      /* '<S20>:31:1' sf_internal_predicateOutput = ... */
      /* '<S20>:31:1' ~MainRelayState; */
      if (!(PMSM_Input.AppComm.MainRelayState != 0U)) {
        /* Transition: '<S20>:31' */
        Algorithm_DW.is_LV = Algorithm_IN_wait_perchg;

        /* Entry 'wait_perchg': '<S20>:24' */
        /* '<S20>:24:1' OV_fault(2)=0; */
        Algorithm_DW.OV_fault[1] = 0U;
      }
      break;

     case Algorithm_IN_Normal_k:
      /* During 'Normal': '<S20>:29' */
      /* '<S20>:26:1' sf_internal_predicateOutput = ... */
      /* '<S20>:26:1' Volt<PMSM_Param.LV3; */
      if (rtb_Volt < PMSM_Param.LV3) {
        /* Transition: '<S20>:26' */
        Algorithm_DW.is_LV = Algorithm_IN_LowVolt3;

        /* Entry 'LowVolt3': '<S20>:25' */
        /* '<S20>:25:1' OV_fault(2)=1; */
        Algorithm_DW.OV_fault[1] = 1U;
      }
      break;

     default:
      /* During 'wait_perchg': '<S20>:24' */
      /* '<S20>:28:1' sf_internal_predicateOutput = ... */
      /* '<S20>:28:1' MainRelayState; */
      if (PMSM_Input.AppComm.MainRelayState != 0U) {
        /* Transition: '<S20>:28' */
        Algorithm_DW.is_LV = Algorithm_IN_Normal_k;
      }
      break;
    }
  }

  /* End of Chart: '<S10>/OverLowVolt3' */

  /* S-Function (sfix_bitop): '<S9>/Bitwise Operator' incorporates:
   *  ArithShift: '<S9>/Shift Arithmetic1'
   *  ArithShift: '<S9>/Shift Arithmetic2'
   *  ArithShift: '<S9>/Shift Arithmetic3'
   *  ArithShift: '<S9>/Shift Arithmetic4'
   *  ArithShift: '<S9>/Shift Arithmetic5'
   *  DataStoreRead: '<S1>/Data Store Read1'
   *  DataTypeConversion: '<S9>/Data Type Conversion'
   *  DataTypeConversion: '<S9>/Data Type Conversion1'
   *  DataTypeConversion: '<S9>/Data Type Conversion2'
   *  Logic: '<S10>/Logical Operator1'
   *  Logic: '<S10>/Logical Operator3'
   */
  rtb_BitwiseOperator = (uint32_T)((uint32_T)((uint32_T)((uint32_T)((uint32_T)
    ((uint32_T)((PMSM_Input.AgoSample.IGBT1FaultState != 0U) ||
                (PMSM_Input.AgoSample.IGBT2FaultState != 0U) ||
                (PMSM_Input.AgoSample.IGBT3FaultState != 0U)) | (uint32_T)
     ((uint32_T)Algorithm_DW.OC_fault[1] << 1U)) | (uint32_T)((uint32_T)
    Algorithm_DW.OC_fault[0] << 2U)) | (uint32_T)((uint32_T)
    Algorithm_DW.OV_fault[0] << 3U)) | (uint32_T)((uint32_T)
    Algorithm_DW.OV_fault[1] << 4U)) | (uint32_T)(int16_T)
    (((PMSM_Input.AgoSample.PosSenFaultState1 != 0U) ||
      (PMSM_Input.AgoSample.PosSenFaultState2 != 0U)) << 5U));

  /* Logic: '<S8>/Logical Operator1' incorporates:
   *  DataTypeConversion: '<S11>/Extract Desired Bits'
   *  DataTypeConversion: '<S12>/Extract Desired Bits'
   *  DataTypeConversion: '<S16>/Extract Desired Bits'
   */
  rtb_Switch_a = (((uint16_T)((uint16_T)rtb_BitwiseOperator & 1U) != 0U) ||
                  ((uint16_T)((uint16_T)(uint32_T)(rtb_BitwiseOperator >> 1U) &
    1U) != 0U) || ((uint16_T)((uint16_T)(uint32_T)(rtb_BitwiseOperator >> 3U) &
    1U) != 0U));

  /* Abs: '<S8>/Abs' incorporates:
   *  DataStoreRead: '<S1>/Data Store Read1'
   */
  rtb_Volt = fabsf(PMSM_Input.AgoSample.Speed);

  /* Relay: '<S8>/Relay1' */
  if (rtb_Volt >= PMSM_Param.ASCSpd) {
    Algorithm_DW.Relay1_Mode = true;
  } else {
    if (rtb_Volt <= 500.0F) {
      Algorithm_DW.Relay1_Mode = false;
    }
  }

  /* Switch: '<S8>/Switch1' incorporates:
   *  Relay: '<S8>/Relay1'
   */
  rtb_Switch1_f = (Algorithm_DW.Relay1_Mode && rtb_Switch_a);

  /* Switch: '<S8>/Switch' incorporates:
   *  Relay: '<S8>/Relay1'
   */
  rtb_Switch_a = ((!Algorithm_DW.Relay1_Mode) && rtb_Switch_a);

  /* Chart: '<S5>/Chart' incorporates:
   *  Constant: '<S74>/Constant'
   *  Constant: '<S75>/Constant'
   *  DataStoreRead: '<S1>/Data Store Read2'
   *  DataTypeConversion: '<S13>/Extract Desired Bits'
   *  DataTypeConversion: '<S8>/Data Type Conversion'
   *  Logic: '<S5>/Logical Operator1'
   *  Logic: '<S5>/Logical Operator2'
   *  Logic: '<S8>/Logical Operator4'
   *  RelationalOperator: '<S74>/Compare'
   *  RelationalOperator: '<S75>/Compare'
   */
  /* Gateway: Function-Call
     Subsystem/State/Chart */
  /* During: Function-Call
     Subsystem/State/Chart */
  /* Entry Internal: Function-Call
     Subsystem/State/Chart */
  /* Transition: '<S72>:49' */
  /* '<S72>:18:1' sf_internal_predicateOutput = ... */
  /* '<S72>:18:1' AscEn; */
  if (rtb_Switch1_f || ((uint16_T)((uint16_T)(uint32_T)(rtb_BitwiseOperator >>
         5U) & 1U) != 0U) || (App_Output.ctrl.AscEn != 0U) ||
      (App_Output.fault.PwmWorkMode == 2U)) {
    /* Transition: '<S72>:18' */
    /* Transition: '<S72>:35' */
    /* Asc */
    /* '<S72>:35:1' state = 4; */
    Algorithm_DW.AlgoState = 4;

    /* Transition: '<S72>:43' */
    /* Transition: '<S72>:55' */
    /* Transition: '<S72>:47' */
    /* Transition: '<S72>:85' */
  } else {
    /* Transition: '<S72>:20' */
    /* '<S72>:22:1' sf_internal_predicateOutput = ... */
    /* '<S72>:22:1' OtherErr; */
    if ((App_Output.fault.PwmWorkMode == 0U) || rtb_Switch_a) {
      /* Transition: '<S72>:22' */
      /* Transition: '<S72>:37' */
      /* OffLine */
      /* '<S72>:37:1' state = 3; */
      Algorithm_DW.AlgoState = 3;

      /* Transition: '<S72>:55' */
      /* Transition: '<S72>:47' */
      /* Transition: '<S72>:85' */
    } else {
      /* Transition: '<S72>:51' */
      /* '<S72>:48:1' sf_internal_predicateOutput = ... */
      /* '<S72>:48:1' PowerEn && ~SoftEn; */
      if ((App_Output.power.DRV1_En != 0U) && (!(App_Output.power.DRV2_En != 0U)))
      {
        /* Transition: '<S72>:48' */
        /* Transition: '<S72>:54' */
        /* Ready */
        /* '<S72>:54:1' state =  2; */
        Algorithm_DW.AlgoState = 2;

        /* Transition: '<S72>:47' */
        /* Transition: '<S72>:85' */
      } else {
        /* Transition: '<S72>:80' */
        /* '<S72>:82:1' sf_internal_predicateOutput = ... */
        /* '<S72>:82:1' SoftEn && PowerEn; */
        if ((App_Output.power.DRV2_En != 0U) && (App_Output.power.DRV1_En != 0U))
        {
          /* Transition: '<S72>:82' */
          /* Transition: '<S72>:84' */
          /* Online */
          /* '<S72>:84:1' state =  1; */
          Algorithm_DW.AlgoState = 1;

          /* Transition: '<S72>:85' */
        } else {
          /* Transition: '<S72>:24' */
          /* Idle */
          /* '<S72>:24:1' state =  0; */
          Algorithm_DW.AlgoState = 0;
        }
      }
    }
  }

  /* End of Chart: '<S5>/Chart' */

  /* Gain: '<S76>/Gain1' incorporates:
   *  DataStoreRead: '<S1>/Data Store Read1'
   *  Gain: '<S76>/Gain5'
   */
  rtb_Nm_pu_tmp = 1.0F / PMSM_Param.SpdNorm;
  rtb_Nm_pu = rtb_Nm_pu_tmp * PMSM_Input.AgoSample.Speed;

  /* Saturate: '<S81>/Saturation' incorporates:
   *  DataStoreRead: '<S1>/Data Store Read2'
   */
  if (App_Output.ctrl.PwmFreq > 10000.0F) {
    rtb_PwmFreq = 10000.0F;
  } else if (App_Output.ctrl.PwmFreq < 1000.0F) {
    rtb_PwmFreq = 1000.0F;
  } else {
    rtb_PwmFreq = App_Output.ctrl.PwmFreq;
  }

  /* End of Saturate: '<S81>/Saturation' */

  /* UnitDelay: '<S1>/Unit Delay' */
  rtb_Ago_Out_Cur_loop_Id = Algorithm_DW.UnitDelay_DSTATE.Cur_loop.Id;
  rtb_Ago_Out_Cur_loop_Iq = Algorithm_DW.UnitDelay_DSTATE.Cur_loop.Iq;
  rtb_Ago_Out_Cur_loop_Ud = Algorithm_DW.UnitDelay_DSTATE.Cur_loop.Ud;
  rtb_Ago_Out_Cur_loop_Uq = Algorithm_DW.UnitDelay_DSTATE.Cur_loop.Uq;
  rtb_Ago_Out_Cur_loop_Vs = Algorithm_DW.UnitDelay_DSTATE.Cur_loop.Vs;

  /* Product: '<S78>/Divide' incorporates:
   *  Constant: '<S78>/Constant'
   */
  rtb_Divide = 1.0F / rtb_PwmFreq;
  for (IntIal_enable = 0; IntIal_enable < 3; IntIal_enable++) {
    /* Gain: '<S67>/Gain1' incorporates:
     *  Gain: '<S67>/Gain3'
     */
    rtb_Gain3[IntIal_enable] = 0.666666687F * (Algorithm_ConstP.Gain3_Gain
      [(int16_T)(IntIal_enable + 6)] * rtb_cur_uvw_pu_idx_2 +
      (Algorithm_ConstP.Gain3_Gain[(int16_T)(IntIal_enable + 3)] *
       rtb_cur_uvw_pu_idx_1 + Algorithm_ConstP.Gain3_Gain[IntIal_enable] *
       rtb_cur_uvw_pu_idx_0));
  }

  /* Gain: '<S76>/Gain2' incorporates:
   *  DataStoreRead: '<S1>/Data Store Read1'
   */
  rtb_Volt = PMSM_Param.MotPole * PMSM_Input.AgoSample.Speed;

  /* Gain: '<S63>/Gain1' */
  rtb_Gain1_n = 0.104719758F * rtb_Volt;

  /* Switch: '<S76>/Switch4' incorporates:
   *  Constant: '<S76>/Constant3'
   *  Constant: '<S80>/Constant'
   *  DataStoreRead: '<S1>/Data Store Read1'
   *  DataStoreRead: '<S1>/Data Store Read2'
   *  RelationalOperator: '<S80>/Compare'
   */
  if (PMSM_Input.AppSample.CalibStep == 2U) {
    rtb_Switch_or = App_Output.ctrl.CalibZeroPoint;
  } else {
    rtb_Switch_or = PMSM_Param.ZeroPoint;
  }

  /* End of Switch: '<S76>/Switch4' */

  /* Sum: '<S76>/Subtract' incorporates:
   *  DataStoreRead: '<S1>/Data Store Read1'
   *  DataTypeConversion: '<S76>/Data Type Conversion'
   */
  rtb_cur_uvw_pu_idx_0 = (real32_T)PMSM_Input.AgoSample.ThetaRT - rtb_Switch_or;

  /* Switch: '<S76>/Switch2' incorporates:
   *  Bias: '<S76>/Bias1'
   *  Constant: '<S79>/Constant'
   *  RelationalOperator: '<S79>/Compare'
   */
  if (rtb_cur_uvw_pu_idx_0 < 0.0F) {
    rtb_cur_uvw_pu_idx_0 += 4095.0F;
  }

  /* End of Switch: '<S76>/Switch2' */

  /* Switch: '<S76>/Switch1' incorporates:
   *  Constant: '<S76>/Constant'
   *  Constant: '<S76>/Constant1'
   *  Sum: '<S76>/Add'
   */
  if (PMSM_Param.ResolverDirChg != 0U) {
    rtb_cur_uvw_pu_idx_0 = 4095.0F - rtb_cur_uvw_pu_idx_0;
  }

  /* End of Switch: '<S76>/Switch1' */

  /* Gain: '<S76>/Gain3' incorporates:
   *  Gain: '<S76>/Gain4'
   */
  rtb_cur_uvw_pu_idx_0 = PMSM_Param.PoleRatio * rtb_cur_uvw_pu_idx_0 *
    0.00153435534F;

  /* Switch: '<S63>/Switch1' incorporates:
   *  Constant: '<S63>/Constant3'
   *  DataStoreRead: '<S1>/Data Store Read2'
   *  Gain: '<S63>/Gain'
   *  Product: '<S63>/Product'
   *  Sum: '<S63>/Add'
   */
  if (App_Output.ctrl.AngleSetEn != 0U) {
    rtb_ParkCompTheta = App_Output.ctrl.AngleRefSet;
  } else {
    rtb_ParkCompTheta = rtb_cur_uvw_pu_idx_0 - 1.0E-6F * PMSM_Param.ParkComp *
      rtb_Gain1_n;
  }

  /* End of Switch: '<S63>/Switch1' */

  /* Outputs for Enabled SubSystem: '<S66>/Subsystem1' incorporates:
   *  EnablePort: '<S71>/Enable'
   */
  /* Fcn: '<S71>/Fcn' incorporates:
   *  Fcn: '<S71>/Fcn1'
   */
  Fcn_tmp = sinf(rtb_ParkCompTheta);
  rtb_Divide_o = cosf(rtb_ParkCompTheta);
  Algorithm_DW.Fcn = rtb_Gain3[0] * rtb_Divide_o + rtb_Gain3[1] * Fcn_tmp;

  /* Fcn: '<S71>/Fcn1' */
  Algorithm_DW.Fcn1 = -rtb_Gain3[0] * Fcn_tmp + rtb_Gain3[1] * rtb_Divide_o;

  /* End of Outputs for SubSystem: '<S66>/Subsystem1' */

  /* Product: '<S63>/Divide' incorporates:
   *  Constant: '<S63>/Constant'
   */
  rtb_Divide_o = 1.0F / rtb_PwmFreq;

  /* Switch: '<S63>/Switch2' incorporates:
   *  Constant: '<S63>/Constant4'
   *  DataStoreRead: '<S1>/Data Store Read2'
   *  Product: '<S63>/Product1'
   *  Sum: '<S63>/Add1'
   */
  if (App_Output.ctrl.AngleSetEn != 0U) {
    rtb_Gain1_n = App_Output.ctrl.AngleRefSet;
  } else {
    rtb_Gain1_n = rtb_Gain1_n * rtb_Divide_o * PMSM_Param.IParkComp +
      rtb_cur_uvw_pu_idx_0;
  }

  /* End of Switch: '<S63>/Switch2' */

  /* Logic: '<S8>/Logical Operator3' incorporates:
   *  DataTypeConversion: '<S14>/Extract Desired Bits'
   *  DataTypeConversion: '<S15>/Extract Desired Bits'
   */
  rtb_Switch_a = !(((uint16_T)((uint16_T)(uint32_T)(rtb_BitwiseOperator >> 2U) &
    1U) != 0U) || ((uint16_T)((uint16_T)(uint32_T)(rtb_BitwiseOperator >> 4U) &
    1U) != 0U));

  /* DiscreteIntegrator: '<S17>/Discrete-Time Integrator' incorporates:
   *  Constant: '<S18>/Constant'
   *  DataTypeConversion: '<S14>/Extract Desired Bits'
   *  DataTypeConversion: '<S15>/Extract Desired Bits'
   *  DataTypeConversion: '<S8>/Data Type Conversion2'
   *  Logic: '<S8>/Logical Operator3'
   *  RelationalOperator: '<S18>/Compare'
   */
  if (Algorithm_DW.DiscreteTimeIntegrator_IC_LOADI != 0U) {
    Algorithm_DW.DiscreteTimeIntegrator_DSTATE = (real32_T)rtb_Switch_a;
    if (Algorithm_DW.DiscreteTimeIntegrator_DSTATE >= 1.0F) {
      Algorithm_DW.DiscreteTimeIntegrator_DSTATE = 1.0F;
    } else {
      if (Algorithm_DW.DiscreteTimeIntegrator_DSTATE <= 0.0F) {
        Algorithm_DW.DiscreteTimeIntegrator_DSTATE = 0.0F;
      }
    }
  }

  if ((real32_T)!(((uint16_T)((uint16_T)(uint32_T)(rtb_BitwiseOperator >> 2U) &
         1U) != 0U) || ((uint16_T)((uint16_T)(uint32_T)(rtb_BitwiseOperator >>
          4U) & 1U) != 0U)) < 0.1F) {
    Algorithm_DW.DiscreteTimeIntegrator_DSTATE = (real32_T)rtb_Switch_a;
    if (Algorithm_DW.DiscreteTimeIntegrator_DSTATE >= 1.0F) {
      Algorithm_DW.DiscreteTimeIntegrator_DSTATE = 1.0F;
    } else {
      if (Algorithm_DW.DiscreteTimeIntegrator_DSTATE <= 0.0F) {
        Algorithm_DW.DiscreteTimeIntegrator_DSTATE = 0.0F;
      }
    }
  }

  if (Algorithm_DW.DiscreteTimeIntegrator_DSTATE >= 1.0F) {
    Algorithm_DW.DiscreteTimeIntegrator_DSTATE = 1.0F;
  } else {
    if (Algorithm_DW.DiscreteTimeIntegrator_DSTATE <= 0.0F) {
      Algorithm_DW.DiscreteTimeIntegrator_DSTATE = 0.0F;
    }
  }

  /* Outputs for Enabled SubSystem: '<S1>/IsCtrl' incorporates:
   *  EnablePort: '<S3>/Enable'
   */
  /* RelationalOperator: '<S73>/Compare' incorporates:
   *  Constant: '<S73>/Constant'
   */
  if (Algorithm_DW.AlgoState == 1) {
    if (!Algorithm_DW.IsCtrl_MODE) {
      /* InitializeConditions for DiscreteIntegrator: '<S31>/Discrete-Time Integrator' */
      Algorithm_DW.IdState = 0.0F;

      /* InitializeConditions for DiscreteTransferFcn: '<S43>/Discrete Transfer Fcn3' */
      Algorithm_DW.DiscreteTransferFcn3_states_h = 0.0F;

      /* InitializeConditions for DiscreteIntegrator: '<S44>/Discrete-Time Integrator' */
      Algorithm_DW.AngleWeakState = 0.0F;

      /* InitializeConditions for DiscreteIntegrator: '<S32>/Discrete-Time Integrator' */
      Algorithm_DW.IqState = 0.0F;

      /* InitializeConditions for UnitDelay: '<S44>/Unit Delay' */
      Algorithm_DW.UnitDelay_DSTATE_l = 0.0F;

      /* SystemReset for Chart: '<S44>/Chart' */
      Algorithm_DW.is_active_c3_Algorithm = 0U;
      Algorithm_DW.is_c3_Algorithm = Algorithm_IN_NO_ACTIVE_CHILD;
      Algorithm_DW.IsCtrl_MODE = true;
    }

    /* DataStoreWrite: '<S31>/Data Store Write1' incorporates:
     *  DiscreteIntegrator: '<S31>/Discrete-Time Integrator'
     */
    AlgoFun.PI_Id_Ui = Algorithm_DW.IdState;

    /* Product: '<S43>/Divide1' incorporates:
     *  Constant: '<S43>/Tao'
     *  Sum: '<S43>/Add'
     */
    rtb_cur_uvw_pu_idx_1 = rtb_Divide / (0.003F + rtb_Divide);

    /* Saturate: '<S38>/Saturation' incorporates:
     *  DataStoreRead: '<S1>/Data Store Read1'
     */
    if (PMSM_Input.AppSample.VoltCap > 1000.0F) {
      rtb_Switch_or = 1000.0F;
    } else if (PMSM_Input.AppSample.VoltCap < 10.0F) {
      rtb_Switch_or = 10.0F;
    } else {
      rtb_Switch_or = PMSM_Input.AppSample.VoltCap;
    }

    /* End of Saturate: '<S38>/Saturation' */

    /* DiscreteTransferFcn: '<S43>/Discrete Transfer Fcn3' incorporates:
     *  Abs: '<S38>/Abs2'
     *  Constant: '<S43>/Constant'
     *  Gain: '<S38>/Gain1'
     *  Product: '<S38>/Divide'
     *  Product: '<S43>/Divide1'
     *  Sum: '<S43>/Subtract'
     */
    Fcn_tmp = fabsf(PMSM_Param.SpdNorm * rtb_Nm_pu) / rtb_Switch_or -
      (rtb_cur_uvw_pu_idx_1 - 1.0F) * Algorithm_DW.DiscreteTransferFcn3_states_h;
    rtb_Saturation1 = rtb_cur_uvw_pu_idx_1 * Fcn_tmp + 0.0F *
      Algorithm_DW.DiscreteTransferFcn3_states_h;

    /* Gain: '<S38>/Gain4' incorporates:
     *  DataStoreRead: '<S1>/Data Store Read2'
     *  DiscreteIntegrator: '<S17>/Discrete-Time Integrator'
     *  Product: '<S38>/Product'
     */
    rtb_cur_uvw_pu_idx_1 = App_Output.ctrl.IsRef *
      Algorithm_DW.DiscreteTimeIntegrator_DSTATE * 1000.0F;

    /* Abs: '<S38>/Abs' */
    rtb_Switch_or = fabsf(rtb_cur_uvw_pu_idx_1);

    /* Lookup_n-D: '<S38>/Id_Table1' incorporates:
     *  DiscreteTransferFcn: '<S43>/Discrete Transfer Fcn3'
     */
    bpIdx = plook_u32ff_evenca(rtb_Saturation1, 18.0555553F, 2.08333397F, 24UL,
      &rtb_cur_uvw_pu_idx_2);
    rtb_Gain_a[0UL] = rtb_cur_uvw_pu_idx_2;
    bpIndices[0UL] = bpIdx;
    bpIdx = plook_u32ff_evenca(rtb_Switch_or, 0.0F, 71.4285736F, 14UL,
      &rtb_cur_uvw_pu_idx_2);
    rtb_Gain_a[1UL] = rtb_cur_uvw_pu_idx_2;
    bpIndices[1UL] = bpIdx;
    rtb_Id_Table1 = intrp2d_fu32fla_pw(bpIndices, rtb_Gain_a,
      Algorithm_ConstP.Id_Table1_tableData, 25UL, Algorithm_ConstP.pooled22);

    /* Lookup_n-D: '<S38>/Iq_Table1' incorporates:
     *  DiscreteTransferFcn: '<S43>/Discrete Transfer Fcn3'
     */
    bpIdx = plook_u32ff_evenca(rtb_Saturation1, 18.0555553F, 2.08333397F, 24UL,
      &rtb_cur_uvw_pu_idx_2);
    fractions[0UL] = rtb_cur_uvw_pu_idx_2;
    bpIndices_0[0UL] = bpIdx;
    bpIdx = plook_u32ff_evenca(rtb_Switch_or, 0.0F, 71.4285736F, 14UL,
      &rtb_cur_uvw_pu_idx_2);
    fractions[1UL] = rtb_cur_uvw_pu_idx_2;
    bpIndices_0[1UL] = bpIdx;
    rtb_Iq_Table1 = intrp2d_fu32fla_pw(bpIndices_0, fractions,
      Algorithm_ConstP.Iq_Table1_tableData, 25UL, Algorithm_ConstP.pooled22);

    /* DataTypeConversion: '<S38>/Data Type Conversion' */
    rtb_Switch_or = floorf(rtb_cur_uvw_pu_idx_1);
    if (rtIsNaNF(rtb_Switch_or) || rtIsInfF(rtb_Switch_or)) {
      rtb_Switch_or = 0.0F;
    } else {
      rtb_Switch_or = fmodf(rtb_Switch_or, 65536.0F);
    }

    IntIal_enable = rtb_Switch_or < 0.0F ? (int16_T)-(int16_T)(uint16_T)
      -rtb_Switch_or : (int16_T)(uint16_T)rtb_Switch_or;

    /* End of DataTypeConversion: '<S38>/Data Type Conversion' */

    /* Signum: '<S38>/Sign' */
    if (IntIal_enable < 0) {
      IntIal_enable = -1;
    } else {
      IntIal_enable = (IntIal_enable > 0);
    }

    /* End of Signum: '<S38>/Sign' */

    /* Product: '<S38>/Product1' */
    rtb_Switch_or = rtb_Iq_Table1 * (real32_T)IntIal_enable;

    /* Fcn: '<S41>/x->theta' incorporates:
     *  Bias: '<S38>/Bias'
     */
    rtb_xtheta = rt_atan2f_snf(rtb_Switch_or, rtb_Id_Table1 + 400.0F);

    /* Lookup_n-D: '<S44>/table2' incorporates:
     *  Abs: '<S44>/Abs'
     */
    bpIdx = plook_u32ff_evenca(fabsf(rtb_xtheta), 0.0F, 0.0157868974F, 199UL,
      &rtb_cur_uvw_pu_idx_2);
    rtb_cur_uvw_pu_idx_1 = intrp1d_fu32fla_pw(bpIdx, rtb_cur_uvw_pu_idx_2,
      Algorithm_ConstP.table2_tableData, 199UL);

    /* Fcn: '<S41>/x->r' incorporates:
     *  Bias: '<S38>/Bias'
     */
    rtb_xr = rt_hypotf_snf(rtb_Id_Table1 + 400.0F, rtb_Switch_or);

    /* Sum: '<S40>/Add' incorporates:
     *  Constant: '<S40>/Constant'
     *  DataStoreRead: '<S1>/Data Store Read2'
     *  MinMax: '<S40>/MinMax'
     *  UnitDelay: '<S1>/Unit Delay'
     */
    rtb_Add_n = fminf(PMSM_Param.FW2_ref, App_Output.ctrl.VsRef) -
      Algorithm_DW.UnitDelay_DSTATE.Cur_loop.Vs;

    /* DiscreteIntegrator: '<S44>/Discrete-Time Integrator' */
    rtb_cur_uvw_pu_idx_2 = Algorithm_DW.AngleWeakState;

    /* Sum: '<S44>/Add' incorporates:
     *  DiscreteIntegrator: '<S44>/Discrete-Time Integrator'
     *  Gain: '<S44>/P'
     *  Sum: '<S44>/Sum1'
     */
    rtb_Add_cj = (PMSM_Param.FW2Kp * rtb_Add_n + Algorithm_DW.AngleWeakState) +
      rtb_xr;

    /* Switch: '<S46>/Switch2' incorporates:
     *  Constant: '<S44>/Constant'
     *  RelationalOperator: '<S46>/LowerRelop1'
     *  RelationalOperator: '<S46>/UpperRelop'
     *  Switch: '<S46>/Switch'
     */
    if (rtb_Add_cj > rtb_cur_uvw_pu_idx_1) {
      rtb_Add_cj = rtb_cur_uvw_pu_idx_1;
    } else {
      if (rtb_Add_cj < 0.0F) {
        /* Switch: '<S46>/Switch' incorporates:
         *  Constant: '<S44>/Constant'
         */
        rtb_Add_cj = 0.0F;
      }
    }

    /* End of Switch: '<S46>/Switch2' */

    /* Switch: '<S29>/Switch' incorporates:
     *  Bias: '<S38>/Bias1'
     *  DataStoreRead: '<S1>/Data Store Read2'
     *  Fcn: '<S42>/r->x'
     *  Gain: '<S38>/Gain2'
     */
    if (App_Output.ctrl.IdIqSetEn != 0U) {
      rtb_Switch_or = App_Output.ctrl.IdRefSet;
    } else {
      rtb_Switch_or = 1.0F / (PMSM_Param.CurNorm * 1.4142F) * (rtb_Add_cj * cosf
        (rtb_xtheta) + -400.0F);
    }

    /* End of Switch: '<S29>/Switch' */

    /* Sum: '<S26>/Add' incorporates:
     *  Switch: '<S66>/Switch'
     */
    rtb_cur_uvw_pu_idx_1 = rtb_Switch_or - Algorithm_DW.Fcn;

    /* Product: '<S30>/Divide2' incorporates:
     *  Abs: '<S30>/Abs'
     *  Constant: '<S30>/Constant1'
     *  DataStoreRead: '<S1>/Data Store Read2'
     *  Gain: '<S21>/Gain'
     */
    rtb_Saturation1 = fabsf(PMSM_Param.SpdNorm * PMSM_Param.MotPole / 60.0F *
      App_Output.data_process.NmFilPu) / 25.0F;

    /* Saturate: '<S30>/Saturation1' */
    if (rtb_Saturation1 > 1.0F) {
      rtb_Saturation1 = 1.0F;
    } else {
      if (rtb_Saturation1 < 1.0F) {
        rtb_Saturation1 = 1.0F;
      }
    }

    /* End of Saturate: '<S30>/Saturation1' */

    /* Product: '<S31>/Product' incorporates:
     *  Constant: '<S31>/Constant'
     *  DiscreteIntegrator: '<S31>/Discrete-Time Integrator'
     *  Gain: '<S31>/P'
     *  Product: '<S31>/Divide1'
     *  Sum: '<S31>/Sum1'
     */
    Algorithm_DW.Saturation = (PMSM_Param.IdKp * rtb_cur_uvw_pu_idx_1 *
      rtb_PwmFreq / PMSM_Param.FreqUp + Algorithm_DW.IdState) * rtb_KCurrPIComp;

    /* Saturate: '<S31>/Saturation' */
    if (Algorithm_DW.Saturation > 1.5F) {
      /* Product: '<S31>/Product' */
      Algorithm_DW.Saturation = 1.5F;
    } else {
      if (Algorithm_DW.Saturation < -1.5F) {
        /* Product: '<S31>/Product' */
        Algorithm_DW.Saturation = -1.5F;
      }
    }

    /* End of Saturate: '<S31>/Saturation' */

    /* DataStoreWrite: '<S32>/Data Store Write1' incorporates:
     *  DiscreteIntegrator: '<S32>/Discrete-Time Integrator'
     */
    AlgoFun.PI_Iq_Ui = Algorithm_DW.IqState;

    /* Switch: '<S28>/Switch' incorporates:
     *  DataStoreRead: '<S1>/Data Store Read2'
     *  Fcn: '<S42>/theta->y'
     *  Gain: '<S38>/Gain3'
     */
    if (App_Output.ctrl.IdIqSetEn != 0U) {
      rtb_Add_a = App_Output.ctrl.IqRefSet;
    } else {
      rtb_Add_a = 1.0F / (PMSM_Param.CurNorm * 1.4142F) * (rtb_Add_cj * sinf
        (rtb_xtheta));
    }

    /* End of Switch: '<S28>/Switch' */

    /* Sum: '<S27>/Add' incorporates:
     *  Switch: '<S66>/Switch'
     */
    rtb_SumofElements = rtb_Add_a - Algorithm_DW.Fcn1;

    /* Gain: '<S32>/I' */
    rtb_xtheta = PMSM_Param.IqKi * 1000.0F * rtb_SumofElements;

    /* Product: '<S32>/Product' incorporates:
     *  Constant: '<S32>/Constant'
     *  DiscreteIntegrator: '<S32>/Discrete-Time Integrator'
     *  Gain: '<S32>/P'
     *  Product: '<S32>/Divide1'
     *  Sum: '<S32>/Sum1'
     */
    Algorithm_DW.Saturation_e = (PMSM_Param.IqKp * rtb_SumofElements *
      rtb_PwmFreq / PMSM_Param.FreqUp + Algorithm_DW.IqState) * rtb_KCurrPIComp;

    /* Saturate: '<S32>/Saturation' */
    if (Algorithm_DW.Saturation_e > 1.5F) {
      /* Product: '<S32>/Product' */
      Algorithm_DW.Saturation_e = 1.5F;
    } else {
      if (Algorithm_DW.Saturation_e < -1.5F) {
        /* Product: '<S32>/Product' */
        Algorithm_DW.Saturation_e = -1.5F;
      }
    }

    /* End of Saturate: '<S32>/Saturation' */

    /* DataStoreWrite: '<S28>/Data Store Write1' */
    AlgoFun.IqRef = rtb_Add_a;

    /* DataStoreWrite: '<S29>/Data Store Write2' */
    AlgoFun.IdRef = rtb_Switch_or;

    /* Outputs for Enabled SubSystem: '<S33>/Subsystem1' incorporates:
     *  EnablePort: '<S37>/Enable'
     */
    /* Fcn: '<S37>/Fcn' */
    Algorithm_DW.Fcn_l = Algorithm_DW.Saturation * cosf(rtb_Gain1_n) -
      Algorithm_DW.Saturation_e * sinf(rtb_Gain1_n);

    /* Fcn: '<S37>/Fcn1' */
    Algorithm_DW.Fcn1_e = Algorithm_DW.Saturation * sinf(rtb_Gain1_n) +
      Algorithm_DW.Saturation_e * cosf(rtb_Gain1_n);

    /* End of Outputs for SubSystem: '<S33>/Subsystem1' */

    /* DataStoreWrite: '<S22>/Data Store Write1' incorporates:
     *  Switch: '<S33>/Switch'
     */
    AlgoFun.Ipark_Alpha = Algorithm_DW.Fcn_l;

    /* DataStoreWrite: '<S22>/Data Store Write2' incorporates:
     *  Switch: '<S33>/Switch'
     */
    AlgoFun.Ipark_Beta = Algorithm_DW.Fcn1_e;

    /* DataStoreWrite: '<S38>/Data Store Write1' */
    AlgoFun.IdWeak = rtb_Id_Table1;

    /* DataStoreWrite: '<S38>/Data Store Write2' */
    AlgoFun.Ld = rtb_xr;

    /* DataStoreWrite: '<S38>/Data Store Write3' */
    AlgoFun.If = rtb_Iq_Table1;

    /* DataStoreWrite: '<S38>/Data Store Write4' */
    AlgoFun.AngleWeak = rtb_Add_cj;

    /* DataStoreWrite: '<S44>/Data Store Write1' incorporates:
     *  DiscreteIntegrator: '<S44>/Discrete-Time Integrator'
     */
    AlgoFun.PI_Angle_Ui = Algorithm_DW.AngleWeakState;

    /* Chart: '<S44>/Chart' incorporates:
     *  UnitDelay: '<S1>/Unit Delay'
     */
    /* Gateway: Function-Call
       Subsystem/IsCtrl/FieldWeak
     / fieldweak/AngleWeak/Subsystem3/Chart */
    /* During: Function-Call
       Subsystem/IsCtrl/FieldWeak
     / fieldweak/AngleWeak/Subsystem3/Chart */
    if (Algorithm_DW.is_active_c3_Algorithm == 0U) {
      /* Entry: Function-Call
         Subsystem/IsCtrl/FieldWeak
       / fieldweak/AngleWeak/Subsystem3/Chart */
      Algorithm_DW.is_active_c3_Algorithm = 1U;

      /* Entry Internal: Function-Call
         Subsystem/IsCtrl/FieldWeak
       / fieldweak/AngleWeak/Subsystem3/Chart */
      /* Transition: '<S45>:3' */
      Algorithm_DW.is_c3_Algorithm = Algorithm_IN_Initial_state;

      /* Entry 'Initial_state': '<S45>:2' */
      /* '<S45>:2:1' IntIal_enable=1; */
      IntIal_enable = 1;
    } else if (Algorithm_DW.is_c3_Algorithm == 1U) {
      /* During 'Initial_state': '<S45>:2' */
      /* '<S45>:13:1' sf_internal_predicateOutput = ... */
      /* '<S45>:13:1' Vs<PMSM_Param.FW2_ref/2; */
      if (Algorithm_DW.UnitDelay_DSTATE.Cur_loop.Vs < PMSM_Param.FW2_ref / 2.0F)
      {
        /* Transition: '<S45>:13' */
        Algorithm_DW.is_c3_Algorithm = Algorithm_IN_Start_int;

        /* Entry 'Start_int': '<S45>:5' */
        /* '<S45>:5:1' IntIal_enable=0; */
        IntIal_enable = 0;
      } else {
        /* '<S45>:2:1' IntIal_enable=1; */
        IntIal_enable = 1;
      }
    } else {
      /* During 'Start_int': '<S45>:5' */
      /* '<S45>:12:1' sf_internal_predicateOutput = ... */
      /* '<S45>:12:1' Vs>=PMSM_Param.FW2_ref; */
      if (Algorithm_DW.UnitDelay_DSTATE.Cur_loop.Vs >= PMSM_Param.FW2_ref) {
        /* Transition: '<S45>:12' */
        Algorithm_DW.is_c3_Algorithm = Algorithm_IN_Initial_state;

        /* Entry 'Initial_state': '<S45>:2' */
        /* '<S45>:2:1' IntIal_enable=1; */
        IntIal_enable = 1;
      } else {
        /* '<S45>:5:1' IntIal_enable=0; */
        IntIal_enable = 0;
      }
    }

    /* End of Chart: '<S44>/Chart' */

    /* Gain: '<S51>/sqrt3' incorporates:
     *  Switch: '<S33>/Switch'
     */
    rtb_SumofElements = 1.73205078F * Algorithm_DW.Fcn_l;

    /* Sum: '<S51>/Add' incorporates:
     *  Switch: '<S33>/Switch'
     */
    rtb_Add_a = rtb_SumofElements + Algorithm_DW.Fcn1_e;

    /* Sum: '<S51>/Subtract' incorporates:
     *  Switch: '<S33>/Switch'
     */
    rtb_SumofElements = Algorithm_DW.Fcn1_e - rtb_SumofElements;

    /* Gain: '<S51>/Gain' */
    rtb_Gain_a[0] = 0.5F * rtb_Add_a;
    rtb_Gain_a[1] = 0.5F * rtb_SumofElements;

    /* Sum: '<S52>/Add' incorporates:
     *  Constant: '<S56>/Constant'
     *  Constant: '<S57>/Constant'
     *  Constant: '<S58>/Constant'
     *  Gain: '<S52>/Gain'
     *  Gain: '<S52>/Gain1'
     *  RelationalOperator: '<S56>/Compare'
     *  RelationalOperator: '<S57>/Compare'
     *  RelationalOperator: '<S58>/Compare'
     *  Switch: '<S33>/Switch'
     */
    rtb_Add_g = (uint16_T)((uint16_T)((uint16_T)((uint16_T)(rtb_Gain_a[0] < 0.0F)
      << 2U) + (uint16_T)(Algorithm_DW.Fcn1_e > 0.0F)) + (uint16_T)((uint16_T)
      (rtb_Gain_a[1] < 0.0F) << 1U));

    /* MultiPortSwitch: '<S53>/Multiport Switch' incorporates:
     *  Gain: '<S53>/Gain'
     *  Switch: '<S33>/Switch'
     */
    switch (rtb_Add_g) {
     case 1:
      rtb_Id_Table1 = rtb_Gain_a[1];
      rtb_Iq_Table1 = rtb_Gain_a[0];
      break;

     case 2:
      rtb_Id_Table1 = rtb_Gain_a[0];
      rtb_Iq_Table1 = -Algorithm_DW.Fcn1_e;
      break;

     case 3:
      rtb_Id_Table1 = -rtb_Gain_a[1];
      rtb_Iq_Table1 = Algorithm_DW.Fcn1_e;
      break;

     case 4:
      rtb_Id_Table1 = -Algorithm_DW.Fcn1_e;
      rtb_Iq_Table1 = rtb_Gain_a[1];
      break;

     case 5:
      rtb_Id_Table1 = Algorithm_DW.Fcn1_e;
      rtb_Iq_Table1 = -rtb_Gain_a[0];
      break;

     default:
      rtb_Id_Table1 = -rtb_Gain_a[0];
      rtb_Iq_Table1 = -rtb_Gain_a[1];
      break;
    }

    /* End of MultiPortSwitch: '<S53>/Multiport Switch' */

    /* Sum: '<S53>/Sum of Elements' */
    rtb_Switch_or = rtb_Id_Table1 + rtb_Iq_Table1;

    /* Chart: '<S60>/Chart' */
    /* Gateway: Function-Call
       Subsystem/IsCtrl/SVPWM/SVPWM/Subsystem2/Overmodulation/Chart */
    /* During: Function-Call
       Subsystem/IsCtrl/SVPWM/SVPWM/Subsystem2/Overmodulation/Chart */
    /* Entry Internal: Function-Call
       Subsystem/IsCtrl/SVPWM/SVPWM/Subsystem2/Overmodulation/Chart */
    /* Transition: '<S62>:6' */
    /* '<S62>:7:1' sf_internal_predicateOutput = ... */
    /* '<S62>:7:1' T1>T2 && T1>1; */
    if ((rtb_Id_Table1 > rtb_Iq_Table1) && (rtb_Id_Table1 > 1.0F)) {
      /* Transition: '<S62>:7' */
      /* Transition: '<S62>:9' */
      /* '<S62>:9:1' T1out=1; */
      rtb_xr = 1.0F;

      /* '<S62>:9:1' T2out=0; */
      rtb_Add_cj = 0.0F;

      /* Transition: '<S62>:14' */
      /* Transition: '<S62>:13' */
    } else {
      /* Transition: '<S62>:8' */
      /* '<S62>:10:1' sf_internal_predicateOutput = ... */
      /* '<S62>:10:1' T1<=T2 && T2>1; */
      if ((rtb_Id_Table1 <= rtb_Iq_Table1) && (rtb_Iq_Table1 > 1.0F)) {
        /* Transition: '<S62>:10' */
        /* Transition: '<S62>:12' */
        /* '<S62>:12:1' T1out=0; */
        rtb_xr = 0.0F;

        /* '<S62>:12:1' T2out=1; */
        rtb_Add_cj = 1.0F;

        /* Transition: '<S62>:13' */
      } else {
        /* Saturate: '<S53>/Saturation' incorporates:
         *  Sum: '<S53>/Sum of Elements'
         */
        /* Transition: '<S62>:11' */
        /* '<S62>:11:1' T1out=T1/SUM; */
        if (rtb_Switch_or > 10000.0F) {
          rtb_xr = 10000.0F;
        } else if (rtb_Switch_or < 0.1F) {
          rtb_xr = 0.1F;
        } else {
          rtb_xr = rtb_Switch_or;
        }

        /* End of Saturate: '<S53>/Saturation' */
        rtb_xr = rtb_Id_Table1 / rtb_xr;

        /* '<S62>:11:1' T2out=1-T1out; */
        rtb_Add_cj = 1.0F - rtb_xr;
      }
    }

    /* End of Chart: '<S60>/Chart' */

    /* Switch: '<S53>/Switch' incorporates:
     *  Sum: '<S53>/Sum of Elements'
     */
    /* Transition: '<S62>:15' */
    if (rtb_Switch_or > 1.0F) {
      rtb_Id_Table1 = rtb_xr;
      rtb_Iq_Table1 = rtb_Add_cj;
    }

    /* End of Switch: '<S53>/Switch' */

    /* Sum: '<S53>/Sum of Elements1' incorporates:
     *  Sum: '<S54>/Sum of Elements2'
     */
    rtb_Switch_or = rtb_Id_Table1 + rtb_Iq_Table1;

    /* Switch: '<S53>/Switch1' incorporates:
     *  Constant: '<S53>/5SVPWM_enable'
     *  Constant: '<S53>/Constant1'
     *  Gain: '<S53>/Gain2'
     *  Sum: '<S53>/Subtract1'
     *  Sum: '<S53>/Sum of Elements1'
     */
    if (PMSM_Param.SV5En != 0U) {
      rtb_xr = 1.0F - rtb_Switch_or;
    } else {
      rtb_xr = (1.0F - rtb_Switch_or) * 0.5F;
    }

    /* End of Switch: '<S53>/Switch1' */

    /* MultiPortSwitch: '<S54>/Multiport Switch' incorporates:
     *  Sum: '<S54>/Sum of Elements1'
     *  Sum: '<S54>/Sum of Elements2'
     */
    switch (rtb_Add_g) {
     case 1:
      Algorithm_DW.Subtract1[0] = rtb_Iq_Table1 + rtb_xr;
      Algorithm_DW.Subtract1[1] = (rtb_Id_Table1 + rtb_Iq_Table1) + rtb_xr;
      Algorithm_DW.Subtract1[2] = rtb_xr;
      break;

     case 2:
      Algorithm_DW.Subtract1[0] = (rtb_Id_Table1 + rtb_Iq_Table1) + rtb_xr;
      Algorithm_DW.Subtract1[1] = rtb_xr;
      Algorithm_DW.Subtract1[2] = rtb_Iq_Table1 + rtb_xr;
      break;

     case 3:
      Algorithm_DW.Subtract1[0] = (rtb_Id_Table1 + rtb_Iq_Table1) + rtb_xr;
      Algorithm_DW.Subtract1[1] = rtb_Iq_Table1 + rtb_xr;
      Algorithm_DW.Subtract1[2] = rtb_xr;
      break;

     case 4:
      Algorithm_DW.Subtract1[0] = rtb_xr;
      Algorithm_DW.Subtract1[1] = rtb_Iq_Table1 + rtb_xr;
      Algorithm_DW.Subtract1[2] = (rtb_Id_Table1 + rtb_Iq_Table1) + rtb_xr;
      break;

     case 5:
      Algorithm_DW.Subtract1[0] = rtb_xr;
      Algorithm_DW.Subtract1[1] = (rtb_Id_Table1 + rtb_Iq_Table1) + rtb_xr;
      Algorithm_DW.Subtract1[2] = rtb_Iq_Table1 + rtb_xr;
      break;

     default:
      Algorithm_DW.Subtract1[0] = rtb_Iq_Table1 + rtb_xr;
      Algorithm_DW.Subtract1[1] = rtb_xr;
      Algorithm_DW.Subtract1[2] = rtb_Switch_or + rtb_xr;
      break;
    }

    /* End of MultiPortSwitch: '<S54>/Multiport Switch' */

    /* Sum: '<S50>/Subtract1' incorporates:
     *  Constant: '<S50>/Constant11'
     */
    Algorithm_DW.Subtract1[0] = 1.0F - Algorithm_DW.Subtract1[0];
    Algorithm_DW.Subtract1[1] = 1.0F - Algorithm_DW.Subtract1[1];
    Algorithm_DW.Subtract1[2] = 1.0F - Algorithm_DW.Subtract1[2];

    /* Update for DiscreteIntegrator: '<S31>/Discrete-Time Integrator' incorporates:
     *  Gain: '<S31>/I'
     *  Product: '<S31>/Divide'
     */
    Algorithm_DW.IdState += PMSM_Param.IdKi * 1000.0F * rtb_cur_uvw_pu_idx_1 /
      rtb_PwmFreq * rtb_Saturation1;
    if (Algorithm_DW.IdState >= 5.0F) {
      Algorithm_DW.IdState = 5.0F;
    } else {
      if (Algorithm_DW.IdState <= -5.0F) {
        Algorithm_DW.IdState = -5.0F;
      }
    }

    /* End of Update for DiscreteIntegrator: '<S31>/Discrete-Time Integrator' */

    /* Update for DiscreteTransferFcn: '<S43>/Discrete Transfer Fcn3' */
    Algorithm_DW.DiscreteTransferFcn3_states_h = Fcn_tmp;

    /* Switch: '<S44>/Switch' incorporates:
     *  Gain: '<S44>/Gain'
     *  Gain: '<S44>/I'
     *  Gain: '<S44>/N'
     *  Product: '<S44>/Product'
     *  UnitDelay: '<S44>/Unit Delay'
     */
    if ((uint16_T)IntIal_enable != 0U) {
      Fcn_tmp = 1000.0F * -Algorithm_DW.UnitDelay_DSTATE_l * rtb_Divide;
    } else {
      Fcn_tmp = PMSM_Param.FW2Ki * rtb_Add_n;
    }

    /* End of Switch: '<S44>/Switch' */

    /* Update for DiscreteIntegrator: '<S44>/Discrete-Time Integrator' */
    Algorithm_DW.AngleWeakState += Fcn_tmp;
    if (Algorithm_DW.AngleWeakState >= 80.0F) {
      Algorithm_DW.AngleWeakState = 80.0F;
    } else {
      if (Algorithm_DW.AngleWeakState <= -80.0F) {
        Algorithm_DW.AngleWeakState = -80.0F;
      }
    }

    /* End of Update for DiscreteIntegrator: '<S44>/Discrete-Time Integrator' */

    /* Update for DiscreteIntegrator: '<S32>/Discrete-Time Integrator' incorporates:
     *  Product: '<S32>/Divide'
     */
    Algorithm_DW.IqState += rtb_xtheta / rtb_PwmFreq * rtb_Saturation1;
    if (Algorithm_DW.IqState >= 5.0F) {
      Algorithm_DW.IqState = 5.0F;
    } else {
      if (Algorithm_DW.IqState <= -5.0F) {
        Algorithm_DW.IqState = -5.0F;
      }
    }

    /* End of Update for DiscreteIntegrator: '<S32>/Discrete-Time Integrator' */

    /* Update for UnitDelay: '<S44>/Unit Delay' */
    Algorithm_DW.UnitDelay_DSTATE_l = rtb_cur_uvw_pu_idx_2;
  } else {
    if (Algorithm_DW.IsCtrl_MODE) {
      /* Disable for Outport: '<S3>/Tcom' */
      Algorithm_DW.Subtract1[0] = 1.0F;
      Algorithm_DW.Subtract1[1] = 1.0F;
      Algorithm_DW.Subtract1[2] = 1.0F;

      /* Disable for Product: '<S31>/Product' incorporates:
       *  Outport: '<S3>/Ud'
       */
      Algorithm_DW.Saturation = 0.0F;

      /* Disable for Product: '<S32>/Product' incorporates:
       *  Outport: '<S3>/Uq'
       */
      Algorithm_DW.Saturation_e = 0.0F;
      Algorithm_DW.IsCtrl_MODE = false;
    }
  }

  /* End of RelationalOperator: '<S73>/Compare' */
  /* End of Outputs for SubSystem: '<S1>/IsCtrl' */

  /* Switch: '<S92>/Switch' incorporates:
   *  Constant: '<S92>/SwapPhase'
   */
  if (PMSM_Param.VWDirChg != 0U) {
    rtb_cur_uvw_pu_idx_1 = Algorithm_DW.Subtract1[2];
    rtb_cur_uvw_pu_idx_2 = Algorithm_DW.Subtract1[1];
  } else {
    rtb_cur_uvw_pu_idx_1 = Algorithm_DW.Subtract1[1];
    rtb_cur_uvw_pu_idx_2 = Algorithm_DW.Subtract1[2];
  }

  /* MultiPortSwitch: '<S7>/Multiport Switch1' incorporates:
   *  Constant: '<S88>/Constant'
   *  Constant: '<S88>/Constant1'
   *  Constant: '<S88>/Constant2'
   *  Constant: '<S88>/Constant3'
   *  Constant: '<S88>/Constant4'
   *  Constant: '<S91>/Constant'
   *  Constant: '<S91>/Constant1'
   *  Constant: '<S91>/Constant2'
   *  Constant: '<S91>/Constant3'
   *  Constant: '<S91>/Constant4'
   *  Constant: '<S92>/Constant4'
   *  Gain: '<S63>/Gain2'
   *  Switch: '<S92>/Switch'
   */
  switch (Algorithm_DW.AlgoState) {
   case 0:
    rtb_PwmFreq = 0.5F;
    break;

   case 1:
    rtb_PwmFreq = Algorithm_DW.Subtract1[0];
    break;

   case 2:
    rtb_PwmFreq = 0.5F;
    break;

   case 3:
    rtb_PwmFreq = 0.5F;
    break;

   default:
    rtb_PwmFreq = 1.0F;
    break;
  }

  switch (Algorithm_DW.AlgoState) {
   case 0:
    rtb_cur_uvw_pu_idx_1 = 0.5F;
    break;

   case 1:
    break;

   case 2:
    rtb_cur_uvw_pu_idx_1 = 0.5F;
    break;

   case 3:
    rtb_cur_uvw_pu_idx_1 = 0.5F;
    break;

   default:
    rtb_cur_uvw_pu_idx_1 = 1.0F;
    break;
  }

  switch (Algorithm_DW.AlgoState) {
   case 0:
    rtb_cur_uvw_pu_idx_2 = 0.5F;
    break;

   case 1:
    break;

   case 2:
    rtb_cur_uvw_pu_idx_2 = 0.5F;
    break;

   case 3:
    rtb_cur_uvw_pu_idx_2 = 0.5F;
    break;

   default:
    rtb_cur_uvw_pu_idx_2 = 1.0F;
    break;
  }

  switch (Algorithm_DW.AlgoState) {
   case 0:
    rtb_Divide_o = 500.0F;
    break;

   case 1:
    rtb_Divide_o *= 1.0E+6F;
    break;

   case 2:
    rtb_Divide_o = 500.0F;
    break;

   case 3:
    rtb_Divide_o = 500.0F;
    break;

   default:
    rtb_Divide_o = 500.0F;
    break;
  }

  switch (Algorithm_DW.AlgoState) {
   case 0:
    rtb_Add_g = 0U;
    break;

   case 1:
    rtb_Add_g = 1U;
    break;

   case 2:
    rtb_Add_g = 0U;
    break;

   case 3:
    rtb_Add_g = 0U;
    break;

   default:
    rtb_Add_g = 2U;
    break;
  }

  /* End of MultiPortSwitch: '<S7>/Multiport Switch1' */

  /* Product: '<S82>/Divide1' incorporates:
   *  Constant: '<S82>/Tao'
   *  Sum: '<S82>/Add'
   */
  rtb_Saturation1 = rtb_Divide / (0.003F + rtb_Divide);

  /* DiscreteTransferFcn: '<S82>/Discrete Transfer Fcn3' incorporates:
   *  Constant: '<S82>/Constant'
   *  Product: '<S82>/Divide1'
   *  Sum: '<S82>/Subtract'
   *  UnitDelay: '<S1>/Unit Delay'
   */
  Fcn_tmp = Algorithm_DW.UnitDelay_DSTATE.Cur_loop.Id - (rtb_Saturation1 - 1.0F)
    * Algorithm_DW.DiscreteTransferFcn3_states;

  /* Product: '<S83>/Divide1' incorporates:
   *  Constant: '<S83>/Tao'
   *  Sum: '<S83>/Add'
   */
  rtb_Add_n = rtb_Divide / (0.003F + rtb_Divide);

  /* DiscreteTransferFcn: '<S83>/Discrete Transfer Fcn3' incorporates:
   *  Constant: '<S83>/Constant'
   *  Product: '<S83>/Divide1'
   *  Sum: '<S83>/Subtract'
   *  UnitDelay: '<S1>/Unit Delay'
   */
  rtb_xtheta = Algorithm_DW.UnitDelay_DSTATE.Cur_loop.Iq - (rtb_Add_n - 1.0F) *
    Algorithm_DW.DiscreteTransferFcn3_states_k;

  /* Product: '<S84>/Divide1' incorporates:
   *  Constant: '<S84>/Tao'
   *  Sum: '<S84>/Add'
   */
  rtb_Switch_or = rtb_Divide / (0.003F + rtb_Divide);

  /* DiscreteTransferFcn: '<S84>/Discrete Transfer Fcn3' incorporates:
   *  Constant: '<S84>/Constant'
   *  Product: '<S84>/Divide1'
   *  Sum: '<S84>/Subtract'
   *  UnitDelay: '<S1>/Unit Delay'
   */
  rtb_Id_Table1 = Algorithm_DW.UnitDelay_DSTATE.Cur_loop.Ud - (rtb_Switch_or -
    1.0F) * Algorithm_DW.DiscreteTransferFcn3_states_ko;

  /* Product: '<S85>/Divide1' incorporates:
   *  Constant: '<S85>/Tao'
   *  Sum: '<S85>/Add'
   */
  rtb_Divide /= 0.003F + rtb_Divide;

  /* DiscreteTransferFcn: '<S85>/Discrete Transfer Fcn3' incorporates:
   *  Constant: '<S85>/Constant'
   *  Product: '<S85>/Divide1'
   *  Sum: '<S85>/Subtract'
   *  UnitDelay: '<S1>/Unit Delay'
   */
  rtb_Iq_Table1 = Algorithm_DW.UnitDelay_DSTATE.Cur_loop.Uq - (rtb_Divide - 1.0F)
    * Algorithm_DW.DiscreteTransferFcn3_states_e;

  /* Math: '<S78>/Math Function' incorporates:
   *  UnitDelay: '<S1>/Unit Delay'
   */
  rtb_xr = rt_hypotf_snf(Algorithm_DW.UnitDelay_DSTATE.Cur_loop.Id,
    Algorithm_DW.UnitDelay_DSTATE.Cur_loop.Iq);

  /* BusCreator: '<S7>/Bus Creator2' incorporates:
   *  BusCreator: '<S7>/BusConversion_InsertedFor_Bus Creator2_at_inport_0'
   *  BusCreator: '<S7>/BusConversion_InsertedFor_Bus Creator2_at_inport_1'
   *  DiscreteTransferFcn: '<S82>/Discrete Transfer Fcn3'
   *  DiscreteTransferFcn: '<S83>/Discrete Transfer Fcn3'
   *  DiscreteTransferFcn: '<S84>/Discrete Transfer Fcn3'
   *  DiscreteTransferFcn: '<S85>/Discrete Transfer Fcn3'
   *  Math: '<S89>/Math Function'
   *  Product: '<S82>/Divide1'
   *  Product: '<S83>/Divide1'
   *  Product: '<S84>/Divide1'
   *  Product: '<S85>/Divide1'
   *  Switch: '<S66>/Switch'
   *  UnitDelay: '<S1>/Unit Delay'
   */
  Algorithm_DW.UnitDelay_DSTATE.IGBT_ctrl.Svpwm_Ta = rtb_PwmFreq;
  Algorithm_DW.UnitDelay_DSTATE.IGBT_ctrl.Svpwm_Tb = rtb_cur_uvw_pu_idx_1;
  Algorithm_DW.UnitDelay_DSTATE.IGBT_ctrl.Svpwm_Tc = rtb_cur_uvw_pu_idx_2;
  Algorithm_DW.UnitDelay_DSTATE.IGBT_ctrl.PwmPeriod = rtb_Divide_o;
  Algorithm_DW.UnitDelay_DSTATE.IGBT_ctrl.PwmWorkMode = rtb_Add_g;
  Algorithm_DW.UnitDelay_DSTATE.IGBT_ctrl.FaultCode2 = rtb_BitwiseOperator;
  Algorithm_DW.UnitDelay_DSTATE.Cur_loop.Id = Algorithm_DW.Fcn;
  Algorithm_DW.UnitDelay_DSTATE.Cur_loop.Iq = Algorithm_DW.Fcn1;
  Algorithm_DW.UnitDelay_DSTATE.Cur_loop.Ud = Algorithm_DW.Saturation;
  Algorithm_DW.UnitDelay_DSTATE.Cur_loop.Uq = Algorithm_DW.Saturation_e;
  Algorithm_DW.UnitDelay_DSTATE.Cur_loop.Vs = rt_hypotf_snf
    (Algorithm_DW.Saturation, Algorithm_DW.Saturation_e);
  Algorithm_DW.UnitDelay_DSTATE.Cur_loop.IdFbkFil = rtb_Saturation1 * Fcn_tmp +
    0.0F * Algorithm_DW.DiscreteTransferFcn3_states;
  Algorithm_DW.UnitDelay_DSTATE.Cur_loop.IqFbkFil = rtb_Add_n * rtb_xtheta +
    0.0F * Algorithm_DW.DiscreteTransferFcn3_states_k;
  Algorithm_DW.UnitDelay_DSTATE.Cur_loop.UdFil = rtb_Switch_or * rtb_Id_Table1 +
    0.0F * Algorithm_DW.DiscreteTransferFcn3_states_ko;
  Algorithm_DW.UnitDelay_DSTATE.Cur_loop.UqFil = rtb_Divide * rtb_Iq_Table1 +
    0.0F * Algorithm_DW.DiscreteTransferFcn3_states_e;
  Algorithm_DW.UnitDelay_DSTATE.Cur_loop.UsFil = 0.0F;
  Algorithm_DW.UnitDelay_DSTATE.Cur_loop.IsFbkFil = 0.0F;
  Algorithm_DW.UnitDelay_DSTATE.Cur_loop.IsFbk = rtb_xr;

  /* DataStoreWrite: '<S1>/Data Store Write2' incorporates:
   *  UnitDelay: '<S1>/Unit Delay'
   */
  Algo_Output = Algorithm_DW.UnitDelay_DSTATE;

  /* DataStoreWrite: '<S63>/Data Store Write1' */
  AlgoFun.Angle_park = rtb_ParkCompTheta;

  /* DataStoreWrite: '<S63>/Data Store Write2' */
  AlgoFun.Angle_Ipark = rtb_Gain1_n;

  /* DataStoreWrite: '<S76>/Data Store Write' */
  AlgoFun.KCurrPIComp = rtb_KCurrPIComp;

  /* DataStoreWrite: '<S76>/Data Store Write1' */
  AlgoFun.ThetaRawE = rtb_cur_uvw_pu_idx_0;

  /* DataStoreWrite: '<S76>/Data Store Write2' incorporates:
   *  DataStoreRead: '<S1>/Data Store Read1'
   *  DataTypeConversion: '<S76>/Data Type Conversion'
   */
  AlgoFun.ThetaRawM = (real32_T)PMSM_Input.AgoSample.ThetaRT;

  /* DataStoreWrite: '<S76>/Data Store Write3' */
  AlgoFun.Nm_pu = rtb_Nm_pu;

  /* Gain: '<S76>/Gain5' incorporates:
   *  DataStoreWrite: '<S76>/Data Store Write4'
   */
  AlgoFun.Ne_pu = rtb_Nm_pu_tmp * rtb_Volt;

  /* DataStoreWrite: '<S81>/Data Store Write1' incorporates:
   *  DataStoreRead: '<S1>/Data Store Read2'
   */
  AlgoFun.IsRef = App_Output.ctrl.IsRef;

  /* DataStoreWrite: '<S78>/Data Store Write1' */
  AlgoFun.IqFbkFil = rtb_Ago_Out_Cur_loop_Iq;

  /* DataStoreWrite: '<S78>/Data Store Write2' */
  AlgoFun.IdFbkFil = rtb_Ago_Out_Cur_loop_Id;

  /* DataStoreWrite: '<S78>/Data Store Write3' */
  AlgoFun.UdFil = rtb_Ago_Out_Cur_loop_Ud;

  /* DataStoreWrite: '<S78>/Data Store Write4' */
  AlgoFun.UqFil = rtb_Ago_Out_Cur_loop_Uq;

  /* DataStoreWrite: '<S78>/Data Store Write5' */
  AlgoFun.UsFil = rtb_Ago_Out_Cur_loop_Vs;

  /* DataStoreWrite: '<S78>/Data Store Write6' */
  AlgoFun.IsFbkFil = rtb_xr;

  /* DataStoreWrite: '<S78>/Data Store Write7' */
  AlgoFun.IsFbk = rtb_xr;

  /* RelationalOperator: '<S17>/Relational Operator' incorporates:
   *  DataTypeConversion: '<S8>/Data Type Conversion2'
   *  DiscreteIntegrator: '<S17>/Discrete-Time Integrator'
   */
  rtb_Switch_a = ((real32_T)rtb_Switch_a >
                  Algorithm_DW.DiscreteTimeIntegrator_DSTATE);

  /* Update for DiscreteIntegrator: '<S17>/Discrete-Time Integrator' incorporates:
   *  DataTypeConversion: '<S17>/Data Type Conversion'
   */
  Algorithm_DW.DiscreteTimeIntegrator_IC_LOADI = 0U;
  Algorithm_DW.DiscreteTimeIntegrator_DSTATE += 0.0001F * (real32_T)rtb_Switch_a;
  if (Algorithm_DW.DiscreteTimeIntegrator_DSTATE >= 1.0F) {
    Algorithm_DW.DiscreteTimeIntegrator_DSTATE = 1.0F;
  } else {
    if (Algorithm_DW.DiscreteTimeIntegrator_DSTATE <= 0.0F) {
      Algorithm_DW.DiscreteTimeIntegrator_DSTATE = 0.0F;
    }
  }

  /* End of Update for DiscreteIntegrator: '<S17>/Discrete-Time Integrator' */

  /* Update for DiscreteTransferFcn: '<S82>/Discrete Transfer Fcn3' */
  Algorithm_DW.DiscreteTransferFcn3_states = Fcn_tmp;

  /* Update for DiscreteTransferFcn: '<S83>/Discrete Transfer Fcn3' */
  Algorithm_DW.DiscreteTransferFcn3_states_k = rtb_xtheta;

  /* Update for DiscreteTransferFcn: '<S84>/Discrete Transfer Fcn3' */
  Algorithm_DW.DiscreteTransferFcn3_states_ko = rtb_Id_Table1;

  /* Update for DiscreteTransferFcn: '<S85>/Discrete Transfer Fcn3' */
  Algorithm_DW.DiscreteTransferFcn3_states_e = rtb_Iq_Table1;

  /* End of Outputs for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_AgoCall_at_outport_1' */
}

/* Model initialize function */
void Algorithm_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)Algorithm_M, 0,
                sizeof(RT_MODEL_Algorithm_T));

  /* states (dwork) */
  (void) memset((void *)&Algorithm_DW, 0,
                sizeof(DW_Algorithm_T));

  /* exported global states */
  AlgoFun = Algorithm_rtZAlgoFun_inspect_bus;

  {
    real_T durationOperatorLastReferenceTi;

    /* Start for DataStoreMemory: '<Root>/App_Output' */
    App_Output = Algorithm_ConstP.App_Output_InitialValue;

    /* SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_AgoCall_at_outport_1' incorporates:
     *  SubSystem: '<Root>/Function-Call Subsystem'
     */
    /* InitializeConditions for DiscreteIntegrator: '<S17>/Discrete-Time Integrator' */
    Algorithm_DW.DiscreteTimeIntegrator_IC_LOADI = 1U;

    /* InitializeConditions for DiscreteTransferFcn: '<S82>/Discrete Transfer Fcn3' */
    Algorithm_DW.DiscreteTransferFcn3_states = 0.0F;

    /* InitializeConditions for DiscreteTransferFcn: '<S83>/Discrete Transfer Fcn3' */
    Algorithm_DW.DiscreteTransferFcn3_states_k = 0.0F;

    /* InitializeConditions for DiscreteTransferFcn: '<S84>/Discrete Transfer Fcn3' */
    Algorithm_DW.DiscreteTransferFcn3_states_ko = 0.0F;

    /* InitializeConditions for DiscreteTransferFcn: '<S85>/Discrete Transfer Fcn3' */
    Algorithm_DW.DiscreteTransferFcn3_states_e = 0.0F;

    /* SystemInitialize for Chart: '<S10>/OverCur12' */
    Algorithm_DW.is_jugment = Algorithm_IN_NO_ACTIVE_CHILD;
    Algorithm_DW.is_active_c7_Algorithm = 0U;
    Algorithm_DW.OC_fault[0] = 0U;
    Algorithm_DW.OC_fault[1] = 0U;

    /* SystemInitialize for Chart: '<S10>/OverLowVolt3' */
    Algorithm_DW.is_LV = Algorithm_IN_NO_ACTIVE_CHILD;
    Algorithm_DW.is_OV = Algorithm_IN_NO_ACTIVE_CHILD;
    Algorithm_DW.is_active_c8_Algorithm = 0U;
    Algorithm_DW.OV_fault[0] = 0U;
    Algorithm_DW.OV_fault[1] = 0U;

    /* SystemInitialize for Chart: '<S5>/Chart' */
    Algorithm_DW.AlgoState = 0;

    /* SystemInitialize for Enabled SubSystem: '<S1>/IsCtrl' */
    /* InitializeConditions for DiscreteIntegrator: '<S31>/Discrete-Time Integrator' */
    Algorithm_DW.IdState = 0.0F;

    /* InitializeConditions for DiscreteTransferFcn: '<S43>/Discrete Transfer Fcn3' */
    Algorithm_DW.DiscreteTransferFcn3_states_h = 0.0F;

    /* InitializeConditions for DiscreteIntegrator: '<S44>/Discrete-Time Integrator' */
    Algorithm_DW.AngleWeakState = 0.0F;

    /* InitializeConditions for DiscreteIntegrator: '<S32>/Discrete-Time Integrator' */
    Algorithm_DW.IqState = 0.0F;

    /* InitializeConditions for UnitDelay: '<S44>/Unit Delay' */
    Algorithm_DW.UnitDelay_DSTATE_l = 0.0F;

    /* SystemInitialize for Chart: '<S44>/Chart' */
    Algorithm_DW.is_active_c3_Algorithm = 0U;
    Algorithm_DW.is_c3_Algorithm = Algorithm_IN_NO_ACTIVE_CHILD;

    /* SystemInitialize for Outport: '<S3>/Tcom' */
    Algorithm_DW.Subtract1[0] = 1.0F;
    Algorithm_DW.Subtract1[1] = 1.0F;
    Algorithm_DW.Subtract1[2] = 1.0F;

    /* End of SystemInitialize for SubSystem: '<S1>/IsCtrl' */
    /* End of SystemInitialize for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_AgoCall_at_outport_1' */

    /* Enable for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_AgoCall_at_outport_1' incorporates:
     *  SubSystem: '<Root>/Function-Call Subsystem'
     */
    /* Enable for Chart: '<S10>/OverCur12' */
    durationOperatorLastReferenceTi = ((Algorithm_M->Timing.clockTick1) * 0.0001)
      - Algorithm_DW.chartDisableTime;
    Algorithm_DW.durationOperatorLastReferenceTi +=
      durationOperatorLastReferenceTi;
    Algorithm_DW.durationOperatorLastReference_f +=
      durationOperatorLastReferenceTi;

    /* End of Enable for RootInportFunctionCallGenerator: '<Root>/RootFcnCall_InsertedFor_AgoCall_at_outport_1' */
  }
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
