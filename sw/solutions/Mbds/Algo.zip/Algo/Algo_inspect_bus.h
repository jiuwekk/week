/*
 * File: Algo_inspect_bus.h
 *
 * Code generated for Simulink model 'Algorithm'.
 *
 * Model version                  : 1.1041
 * Simulink Coder version         : 8.13 (R2017b) 24-Jul-2017
 * C/C++ source code generated on : Thu Sep 30 13:59:21 2021
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. RAM efficiency
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Algo_inspect_bus_h_
#define RTW_HEADER_Algo_inspect_bus_h_
#include "rtwtypes.h"

typedef struct {
  real32_T KCurrPIComp;
  real32_T ThetaRawE;
  real32_T ThetaRawM;
  real32_T Angle_park;
  real32_T Angle_Ipark;
  real32_T Nm_pu;
  real32_T Ne_pu;
  real32_T Clarke_Alpha;
  real32_T Clarke_Beta;
  real32_T IdRef;
  real32_T IqRef;
  real32_T PI_Id_Ui;
  real32_T PI_Iq_Ui;
  real32_T Ipark_Alpha;
  real32_T Ipark_Beta;
  real32_T VsRef1;
  real32_T Ld;
  real32_T IdWeak;
  real32_T PI_IdWeak_Ui;
  real32_T AngleMTPA;
  real32_T VsRef2;
  real32_T AngleWeak;
  real32_T PI_Angle_Ui;
  real32_T IsRef;
  real32_T If;
  real32_T TabNStart;
  real32_T TabNEnd;
  real32_T TabNStep;
  real32_T TqMax;
  real32_T TqLimit;
  real32_T TqReal;
  real32_T IdFbkFil;
  real32_T IqFbkFil;
  real32_T UdFil;
  real32_T UqFil;
  real32_T UsFil;
  real32_T IsFbkFil;
  real32_T IsFbk;
} AlgoFun_inspect_bus;

#endif                                 /* RTW_HEADER_Algo_inspect_bus_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
